/**********************************************************************************************
 * Programmer: Christian Webber
 * Class: CptS 121, Fall 2011; Lab Section 3
 * PA7
 * Created: November 13th, 2011
 * Last Revised: November 30th, 2011
 * Description: This function set allows a menu to be generated and a valid answer
 *							to be selected and returned.
 *
 * File Description: "main.c" contains the main function for the project.
 *********************************************************************************************/
#include "poker.h"

/*************************************************************
 * Function: main ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function controls the program
 * Input parameters: None
 * Returns: None
 * Preconditions: the program needs to be run
 * Postconditions: the program has been run
 *************************************************************/
int main (void)
{
	// control variables
	int prog_state = 0, option = 0;
	// menu item definitions
	char menu_main[][128] = {"Play Game", "Rules", "Quit"};

	// Cycle through program
	while (prog_state >= 0)
	{
		// game loading
		if (prog_state == 0)
		{
			// display the welcome screen
			welcome ();
			// goto the main menu
			prog_state = 1;
		}
		// main menu
		else if (prog_state == 1)
		{
			// get the selected option from the displayed menu
			option = display_selector_menu (1, 3, "Main Menu", menu_main);
			// OPTIONS
			// play game
			if (option == 1)
			{
				game_main ();
				pause_clear (0, 1);
			}
			// display rules
			else if (option == 2)
			{
				display_rules ();
			}
			// exit game
			else
			{
				prog_state = -1;
			}
		}
	}

	// exit program
	return 0;
}