/**********************************************************************************************
 * Programmer: Christian Webber
 * Class: CptS 121, Fall 2011; Lab Section 3
 * PA7
 * Created: November 13th, 2011
 * Last Revised: November 30th, 2011
 *
 * File Description: "game_control.c" contains the main game control function.
 *********************************************************************************************/
#include "poker.h"

/*************************************************************
 * Function: game_main ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function plays a game of 5 hand draw poker
 * Input parameters: None
 * Returns: None
 * Preconditions: the game must be played
 * Postconditions: the game has been played
 *************************************************************/
void game_main (void)
{
	// declare variables
	int game_state = 0, sub_state = 0, i = 0, option = 0;

	PlayerInfo player1Info,
				   player2Info;

	PlayerHand clearedHand;
	Card clearedCard = {-1, -1};

	/* initialize suit array */
	const char *suit[4] = {"Hearts", "Diamonds", "Clubs", "Spades"};
	/* initialize face array */
	const char *face[13] = {"Ace", "Deuce", "Three", "Four", "Five", "Six", "Seven", "Eight",
		"Nine", "Ten", "Jack", "Queen", "King"};

	// menu item definitions
	char menu_betting[][128] = {"View Hand", "View Money", "Place Wager and End Phase", "Fold and End Phase", "Exit Game"};
	char menu_betting2[][128] = {"View Hand", "View Money", "View Wagers", "Place Wager and End Phase", "Fold and End Phase", "Exit Game"};
	char menu_yesNo[][128] = {"Yes", "No"};

	int deck[4][13] = {0},
		cardsUsed = 0,
		playerTurn = 0,
		totalTurns = 0;

	/* GAME STATE
	 * 0 = Game Setup
	 * 1 = New Round
	 * 2 = Draw Phase 1
	 * 3 = Betting Phase 1
	 * 4 = Remove Card(s) Phase and AI 1
	 * 5 = Draw Phase 2
	 * 6 = Betting Phase 2
	 * 7 = AI 2 and Hand Rating
	 * 8 = Round Cleanup
	 * 9 = Endgame
	*/
	while (game_state >= 0)
	{
		// GAME SETUP
		if (game_state == 0)
		{
			// seed random number generator
			seedRandomGenerator (1, 0);
			// Shuffle the deck
			shuffle (deck);
			// determine who pays the first blind.
			playerTurn = randomNumber (1, 2);
			// set AI player settings
			player1Info.isAI = 0;
			player2Info.isAI = 1;
			// set starting money for both players
			player1Info.money = startingMoney ();
			player2Info.money = player1Info.money;
			// set up a cleared hand
			for (i = 0; i < 5; i++)
			{
				clearedHand.hand[i] = clearedCard;
			}
			// clear the screen of any residual text
			pause_clear (0, 1);
			// goto turn decider
			game_state = 1;
		}

		// NEW ROUND
		else if (game_state == 1)
		{
			// increase the turn counter by one
			totalTurns++;
			// clear player's old hands
			player1Info.hand = clearedHand;
			player2Info.hand = clearedHand;
			// clear old wagers
			player1Info.wager = 0;
			player2Info.wager = 0;
			// shuffle the deck if all cards have been used
			if (cardsUsed == 52)
			{
				// Shuffle the deck
				cardsUsed = 0;
				shuffle (deck);
			}
			// Reset player folded info
			player1Info.hasFolded = 0;
			player2Info.hasFolded = 0;
			// State money/turn info
			printf ("ROUND %d\n\nPlayer 1 Cash: $%.2lf\nPlayer 2 Cash: $%.2lf\n",
				totalTurns, player1Info.money, player2Info.money);
			// decide who pays the blind.
			playerTurn = randomNumber (1, 2);
			// if the blind goes to player 1...
			if (playerTurn == 1)
			{
				// make the blind 10% of the player's money
				player1Info.wager = 0.1 * (player1Info.money);
				// say what the blind is
				printf ("Payer 1 pays a blind of $%.2lf\n", player1Info.wager);
			}
			// otherwise it goes to player 2...
			else
			{
				// make the blind 10% of the player's money
				player2Info.wager = 0.1 * (player2Info.money);
				// say what the blind is
				printf ("Payer 2 pays a blind of %.2lf\n", player2Info.wager);
			}
			// pause/clear screen
			pause_clear (1, 1);
			// goto first drawing phase
			game_state = 2;
			// unless somebody has lost!
			if ((player1Info.money <= 0) || (player2Info.money <= 0))
			{
				// goto end game state
				game_state = 9;
			}
		}

		// DRAW PHASE 1
		else if (game_state == 2)
		{
			// print what is happening...
			printf ("The dealer is dealing new cards to both players...");
			// give player 1 cards
			for (i = 0; i < 5; i++)
			{
				// provided there are cards to give...
				if (cardsUsed != 52)
				{
					// deal a new card
					player1Info.hand.hand[i] = dealCard (deck, cardsUsed);
					cardsUsed++;
				}
			}
			// give player 2 cards
			for (i = 0; i < 5; i++)
			{
				// provided there are cards to give...
				if (cardsUsed != 52)
				{
					// deal a new card
					player2Info.hand.hand[i] = dealCard (deck, cardsUsed);
					cardsUsed++;
				}
			}
			// print that the cards have been dealt
			printf ("Cards have been dealt!\n");
			// pause/clear
			pause_clear (1, 1);
			// goto the first betting phase
			game_state = 3;
		}

		// BETTING PHASE 1
		else if (game_state == 3)
		{
			// get a result from a displayed menu
			option = display_selector_menu (1, 5, "Betting Phase 1", menu_betting);
			// OPTIONS
			// view hand
			if (option == 1)
			{
				viewHand (player1Info.hand, face, suit);
			}
			// view money
			else if (option == 2)
			{
				printf ("You have $%.2lf!\n", player1Info.money);
			}
			// place wager
			else if (option == 3)
			{
				player1Info.wager += placeWager (player1Info.money);
				game_state = 4;
			}
			// fold hand
			else if (option == 4)
			{
				player1Info.hasFolded = 1;
				game_state = 8;
			}
			// exit game
			else
			{
				player1Info.money = -1000.00;
				game_state = 9;
			}
		}

		// REMOVE CARDS PHASE AND AI 1
		else if (game_state == 4)
		{
			// get an updated player hand for player 1 by calling the removeCards function
			player1Info.hand = removeCards (player1Info.hand, face, suit);
			// do the ai for player 2
			player2Info = ai_main (player2Info, 1);
			// goto the second drawing phase
			game_state = 5;
		}

		// DRAW PHASE 2
		else if (game_state == 5)
		{
			pause_clear (0, 1);
			printf ("Dealing cards...");
			// give player 1 cards
			for (i = 0; i < 5; i++)
			{
				// if there are still cards...
				if (cardsUsed != 52)
				{
					// check if the card needs replacing...
					if (player1Info.hand.hand[i].face == -1)
					{
						// and replace if it does
						player1Info.hand.hand[i] = dealCard (deck, cardsUsed);
						cardsUsed++;
					}
				}
			}
			// give player 2 cards
			for (i = 0; i < 5; i++)
			{
				// if there are still cards...
				if (cardsUsed != 52)
				{
					// check if the card needs replacing...
					if (player2Info.hand.hand[i].face == -1)
					{
						// and replace if it does
						player2Info.hand.hand[i] = dealCard (deck, cardsUsed);
						cardsUsed++;
					}
				}
			}
			printf ("Cards have been dealt!\n");
			pause_clear (1, 1);
			// goto the second betting phase
			game_state = 6;
		}

		// BETTING PHASE 2
		else if (game_state == 6)
		{
			// get the results from a displayed menu...
			option = display_selector_menu (1, 6, "Betting Phase 2", menu_betting2);
			// OPTIONS
			// view hand
			if (option == 1)
			{
				viewHand (player1Info.hand, face, suit);
			}
			// view money
			else if (option == 2)
			{
				printf ("You have $%.2lf!\n", player1Info.money);
			}
			// view wagers
			else if (option == 3)
			{
				printf ("Player 1 Wager: $%.2lf\n", player1Info.wager);
				printf ("Player 2 Wager: $%.2lf\n", player2Info.wager);
			}
			// place wager
			else if (option == 4)
			{
				player1Info.wager += placeWager (player1Info.money);
				game_state = 7;
			}
			// fold hand
			else if (option == 5)
			{
				player1Info.hasFolded = 1;
				game_state = 8;
			}
			// exit game
			else
			{
				player1Info.money = -1000.00;
				game_state = 9;
			}
		}

		// AI 2 and Hand Rating
		else if (game_state == 7)
		{
			// do the ai for player 2
			player2Info = ai_main (player2Info, 2);
			// rate the hands of player 1 and player 2
			player1Info.handRating = handRating (player1Info.hand);
			player2Info.handRating = handRating (player2Info.hand);
			// goto the round cleanup
			game_state = 8;
		}

		// ROUND CLEANUP
		else if (game_state == 8)
		{
			// first check if either player has folded...
			// if the first player has folded...
			if (player1Info.hasFolded)
			{
				printf ("Player 2 wins the round, Player 1 folded!");
				player1Info.money -= player1Info.wager;
				player2Info.money += player1Info.wager;
			}
			// if the second player has folded...
			else if (player2Info.hasFolded)
			{
				printf ("Player 1 wins the round, Player 2 folded!");
				// adjust player money by wager amount
				player1Info.money += player2Info.wager;
				player2Info.money -= player2Info.wager;
			}
			// otherwise...
			else
			{
				// if the hand rating of the first player is greater than that of the second...
				if (player1Info.handRating > player2Info.handRating)
				{
					// print that player 1 won
					printf ("Player 1 wins the round!");
					// adjust player money by wager amount
					player1Info.money += player2Info.wager;
					player2Info.money -= player2Info.wager;
				}
				// if the hand rating of the second player is greater than that of the first...
				else if (player1Info.handRating < player2Info.handRating)
				{
					// print that player 2 won
					printf ("Player 2 wins the round!");
					// adjust player money by wager amount
					player1Info.money -= player1Info.wager;
					player2Info.money += player1Info.wager;
				}
				// otherwise, it must be a tie
				else
				{
					// print that it is a tie
					printf ("Tie round!");
				}
			}
			printf ("\n");
			pause_clear (1, 0);
			printf ("PLAYER 1 HAND\n");
			viewHand (player1Info.hand, face, suit);
			printf ("\n");
			printf ("PLAYER 2 HAND\n");
			viewHand (player2Info.hand, face, suit);
			// ask if the player wants to play a new round
			option = display_selector_menu (1, 2, "Play a New Round?", menu_yesNo);
			// if they do, go to the new round state
			if (option == 1)
			{
				game_state = 1;
			}
			// otherwise, end the game
			else
			{
				game_state = 9;
			}
		}

		// ENDGAME
		else if (game_state == 9)
		{
			// pause and print that the game is over
			pause_clear (0, 1);
			printf ("Game Over\n");
			// if player 1 has more money than player 2...
			if (player1Info.money > player2Info.money)
			{
				// print that player 1 has won
				printf ("Player 1 wins the game!\n");
			}
			// if player 2 has more money than player 1...
			else if (player1Info.money < player2Info.money)
			{
				// print that player 2 has won
				printf ("Player 2 wins the game!\n");
			}
			// otherwise, it must be a tie
			else
			{
				// print that it is a tie game
				printf ("Tie Game!\n");
			}
			// pause/clear
			pause_clear (1, 1);
			// end the game
			game_state = -1;
		}
	}
}