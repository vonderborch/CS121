/**********************************************************************************************
 * Programmer: Christian Webber
 * Class: CptS 121, Fall 2011; Lab Section 3
 * PA7
 * Created: November 13th, 2011
 * Last Revised: November 30th, 2011
 *
 * File Description: "functions.c" contains the various basic functions for the project.
 *********************************************************************************************/
#include "poker.h"

/*************************************************************
 * Function: welcome ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function shows a welcome message
 * Input parameters: None
 * Returns: None
 * Preconditions: the welcome message must be shown
 * Postconditions: the welcome message has been shown
 *************************************************************/
void welcome (void)
{
	// print message
	printf ("Welcome to Five Hand Draw Poker!\n");
	// pause/clear screen
	pause_clear (1, 1);
}

/*************************************************************
 * Function: display_rules ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function displays the rules of 5 hand draw
 * Input parameters: None
 * Returns: None
 * Preconditions: the rules need to be displayed
 * Postconditions: the rules have been displayed
 *************************************************************/
void display_rules (void)
{
	// print rules title
	printf ("Five Hand Draw Poker Rules (Wikipedia)\n\n");
	// print the rules
	printf ("'In casino play the first betting round begins with the player to the left of the big blind, and subsequent rounds begin with the player to the dealer's left. Home games typically use an ante; the first betting round begins with the player to the dealer's left, and the second round begins with the player who opened the first round. Play begins with each player being dealt five cards, one at a time, all face down. The remaining deck is placed aside, often protected by placing a chip or other marker on it. Players pick up the cards and hold them in their hands, being careful to keep them concealed from the other players, then a round of betting occurs. If more than one player remains after the first round, the draw phase begins. Each player specifies how many of their cards they wish to replace and discards them. The deck is retrieved, and each player is dealt in turn from the deck the same number of cards they discarded so that each player again has five cards. A second after the draw betting round occurs beginning with the player to the dealer's left or else beginning with the player who opened the first round (the latter is common when antes are used instead of blinds). This is followed by a showdown if more than one player remains, in which the player with the best hand wins the pot.'\n");
	// pause/clear
	pause_clear (1, 1);
}

/*************************************************************
 * Function: randomNumber ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function returns a random int
 * Input parameters: the minimum number and max number for the
 *						random number's range
 * Returns: the random number
 * Preconditions: a random number is needed
 * Postconditions: a random number is returned
 *************************************************************/
int randomNumber (int minNum, int maxNum)
{
	// return a random number modded by the max number and added to
	//			by the min number
	return (rand () % maxNum + minNum);
}

/*************************************************************
 * Function: goodIntInputCheck ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function gets a "good" int input
 * Input parameters: the minimum good value, the maximum good value
 * Returns: the good int input
 * Preconditions: a "good" int input value is needed
 * Postconditions: a "good" int input value is returned
 *************************************************************/
int goodIntInputCheck (int minGood, int maxGood)
{
	// declare variables
	int goodInputMain = 0, goodInputSub = 0, input = 0;
	// repeat while the desiered input is not achieved
	while (!goodInputMain)
	{
		// clear the buffer
		_flushall ();
		// get the input, assigned to the input variable.
		// assign the results of the scanf to a variable
		goodInputSub = scanf (" %d", &input);
		// if the scanf was successful...
		if (goodInputSub)
		{
			// check if the input falls in the range...
			if ((input >= minGood) && (input <= maxGood))
			{
				// break the input loop if it does
				goodInputMain = 1;
			}
		}
	}
	// return the "good" input
	return input;
}

/*************************************************************
 * Function: goodDoubleInputCheck ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function gets a "good" double input
 * Input parameters: the minimum good value, the maximum good value
 * Returns: the good double input
 * Preconditions: a "good" double input value is needed
 * Postconditions: a "good" double input value is returned
 *************************************************************/
double goodDoubleInputCheck (double minGood, double maxGood)
{
	// declare the variables
	int goodInputMain = 0, goodInputSub = 0;
	double input = 0.0;
	// repeat while the desiered input is not achieved
	while (!goodInputMain)
	{
		// clear the buffer
		_flushall ();
		// get the input, assigned to the input variable.
		// assign the results of the scanf to a variable
		goodInputSub = scanf (" %lf", &input);
		// check if the scanf was successful
		if (goodInputSub)
		{
			// check if the input falls within desiered range
			if ((input >= minGood) && (input <= maxGood))
			{
				// break the input loop
				goodInputMain = 1;
			}
		}
	}
	// return the "good" input
	return input;
}