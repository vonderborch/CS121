/**********************************************************************************************
 * Programmer: Christian Webber
 * Class: CptS 121, Fall 2011; Lab Section 3
 * PA7
 * Created: November 13th, 2011
 * Last Revised: November 30th, 2011
 *
 * File Description: "game_functions.c" contains the various strictly in-game functions definitions.
 *********************************************************************************************/
#include "poker.h"

/*************************************************************
 * Function: shuffle ()
 * Date Created: ?
 * Date Last Modified: ?
 * Description: This function shuffles the deck
 * Input parameters: the deck to be shuffled
 * Returns: None
 * Preconditions: the deck must be shuffled
 * Postconditions: the deck has been shuffled
 *************************************************************/
void shuffle (int wDeck[][13])
{
	int row = 0;    /* row number */
	int column = 0; /*column number */
	int card = 0;   /* card counter */

	/* for each of the 52 cards, choose slot of deck randomly */
	for (card = 1; card <= 52; card++)
	{
		/* choose new random location until unoccupied slot found */
		do
		{
			row = rand () % 4;
			column = rand () % 13;
		} while (wDeck[row][column] != 0);

		/* place card number in chosen slot of deck */
		wDeck[row][column] = card;
	}
}

/*************************************************************
 * Function: startingMoney ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function gets the starting money
 *					for both players
 * Input parameters: None
 * Returns: the starting money
 * Preconditions: the starting money must be set
 * Postconditions: the starting money has been set
 *************************************************************/
double startingMoney (void)
{
	double money = 0;
	// print the question
	printf ("How much money should each player start out with (10 - 1000)? ");
	// get the money
	_flushall ();
	money = goodDoubleInputCheck (10, 1000);
	// return the money
	return money;
}

/*************************************************************
 * Function: dealCard ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function deals a card from the deck
 * Input parameters: the deck to deal from, the card that is to be dealed
 * Returns: the dealt card
 * Preconditions: a card must be dealt
 * Postconditions: a card has been dealt
 *************************************************************/
Card dealCard (int wDeck[][13], int cardOn)
{
	// declare variables
	int i = 0, j = 0;
	Card tempCard;

	// search row
	for (i = 0; i <= 3; i++)
	{
		// search column
		for (j = 0; j <= 12; j++)
		{
			// check if the row/column is the card to be dealt
			if (wDeck[i][j] == (cardOn + 1))
			{
				// and deal it
				tempCard.suit = i;
				tempCard.face = j;
			}
		}
	}

	// return the card
	return tempCard;
}

/*************************************************************
 * Function: orderCards ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function orders the cards of a player's hand
 * Input parameters: the player's hand
 * Returns: return the player's ordered hand
 * Preconditions: the player's hand needs to be ordered
 * Postconditions: the player's hand has been ordered
 *************************************************************/
PlayerHand orderCards (PlayerHand tempHand)
{
	// declare variables
	int card = 0,
		bestCard = 0,
		cardOn = 0,
		cardsUsed[5] = {0, 0, 0, 0, 0};
	PlayerHand orderedHand;

	// order cards
	for (cardOn = 0; cardOn < 5; cardOn++)
	{
		// set the best card as being -1
		bestCard = -1;
		for (card = 0; card < 5; card++)
		{
			// if the card hasn't been used yet...
			if (!cardsUsed[card])
			{
				// if there is no best card yet...
				if (bestCard == -1)
				{
					// set the current card as the best card
					bestCard = card;
				}
				// otherwise...
				else
				{
					// check if the value of the current card is better than the best one...
					if (tempHand.hand[card].face > tempHand.hand[bestCard].face)
					{
						// if it is, set the new one as the best
						bestCard = card;
					}
				}
			}
		}
		// set the best card as the next one in the ordered hand
		orderedHand.hand[cardOn] = tempHand.hand[bestCard];
		cardsUsed[bestCard] = 1;
	}

	// return the ordered hand
	return orderedHand;
}

/*************************************************************
 * Function: placeWager ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function gets a wager from the player
 * Input parameters: the player's money
 * Returns: the player's wager
 * Preconditions: the player needs to place a wager
 * Postconditions: the player has placed a wager
 *************************************************************/
double placeWager (double playerMoney)
{
	// declare variabels
	double tempWager = 0.0;
	// clear the screen
	pause_clear (0, 1);
	// ask the question
	printf ("How much money will you wager (0.01 - %.2lf)? ", playerMoney);
	// get the result
	_flushall();
	tempWager = goodDoubleInputCheck (0.01, playerMoney);
	// return the wager
	return tempWager;
}

/*************************************************************
 * Function: viewHand ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function shows the hand of a player
 * Input parameters: the player's hand, the face/suit values
 * Returns: None
 * Preconditions: The hand of a player needs to be viewed
 * Postconditions: the hand of a player has been viewed
 *************************************************************/
void viewHand (PlayerHand tempHand, const char *wFace[], const char *wSuit[])
{
	// declare variables
	int i = 0;
	// print the player's cards
	for (i = 0; i < 5; i++)
	{
		if (tempHand.hand[i].face != -1)
		{
			printf ("Card %d: %s of %s\n", (i + 1), wFace[tempHand.hand[i].face], wSuit[tempHand.hand[i].suit]);
		}
	}
	// pause/clear
	pause_clear (1, 1);
}

/*************************************************************
 * Function: removeCards ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function allows the player to choose which
 *					cards they want to remove
 * Input parameters: the player's hand, and the face/suit values
 * Returns: the updated player's hand
 * Preconditions: the player needs to remove cards from their hand
 * Postconditions: the player has removed cards from their hand
 *************************************************************/
PlayerHand removeCards (PlayerHand tempHand, const char *wFace[], const char *wSuit[])
{
	// declare variables
	PlayerHand finalHand = tempHand;
	int option = 0, isRemoving = 1, cardOn = 0;
	char menu_removal[][128] = {"View Hand", "Card 1", "Card 2", "Card 3", "Card 4", "Card 5", "Stop Removing Cards"};

	// show the menu while the player is still removing cards
	do
	{
		// get a choosen option from a displayed menu
		option = display_selector_menu (1, 7, "Remove Card...", menu_removal);
		// OPTIONS
		// show hand
		if (option == 1)
		{
			viewHand (finalHand, wFace, wSuit);
		}
		// remove the first card
		else if (option == 2)
		{
			// set card number
			cardOn = 0;
			// has the card been removed already?
			if (finalHand.hand[cardOn].face != -1)
			{
				// if it hasn't, remove it and say so
				finalHand.hand[cardOn].face = -1;
				finalHand.hand[cardOn].suit = -1;
				printf ("Card %d Removed!\n", cardOn + 1);
			}
			// otherwise, say it has been removed...
			else
			{
				printf ("Card Already Removed!\n");
			}
		}
		// remove the second card
		else if (option == 3)
		{
			// set card number
			cardOn = 1;
			// has the card been removed already?
			if (finalHand.hand[cardOn].face != -1)
			{
				// if it hasn't, remove it and say so
				finalHand.hand[cardOn].face = -1;
				finalHand.hand[cardOn].suit = -1;
				printf ("Card %d Removed!\n", cardOn + 1);
			}
			// otherwise, say it has been removed...
			else
			{
				printf ("Card Already Removed!\n");
			}
		}
		// remove the third card
		else if (option == 4)
		{
			// set card number
			cardOn = 2;
			// has the card been removed already?
			if (finalHand.hand[cardOn].face != -1)
			{
				// if it hasn't, remove it and say so
				finalHand.hand[cardOn].face = -1;
				finalHand.hand[cardOn].suit = -1;
				printf ("Card %d Removed!\n", cardOn + 1);
			}
			// otherwise, say it has been removed...
			else
			{
				printf ("Card Already Removed!\n");
			}
		}
		// remove the fourth card
		else if (option == 5)
		{
			// set card number
			cardOn = 3;
			// has the card been removed already?
			if (finalHand.hand[cardOn].face != -1)
			{
				// if it hasn't, remove it and say so
				finalHand.hand[cardOn].face = -1;
				finalHand.hand[cardOn].suit = -1;
				printf ("Card %d Removed!\n", cardOn + 1);
			}
			// otherwise, say it has been removed...
			else
			{
				printf ("Card Already Removed!\n");
			}
		}
		// remove the fifth card
		else if (option == 6)
		{
			// set card number
			cardOn = 4;
			// has the card been removed already?
			if (finalHand.hand[cardOn].face != -1)
			{
				// if it hasn't, remove it and say so
				finalHand.hand[cardOn].face = -1;
				finalHand.hand[cardOn].suit = -1;
				printf ("Card %d Removed!\n", cardOn + 1);
			}
			// otherwise, say it has been removed...
			else
			{
				printf ("Card Already Removed!\n");
			}
		}
		// stop removing cards
		else
		{
			isRemoving = 0;
		}
	} while (isRemoving);

	// return the updated hand
	return finalHand;
}

/*************************************************************
 * Function: handRating ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function rates a player's hand
 * Input parameters: the player's hand to be rated
 * Returns: the rating of the player's hand
 * Preconditions: the player's hand needs to be rated
 * Postconditions: the player's hand has been rated
 *************************************************************/
int handRating (PlayerHand tempHand)
{
	// temp variable
	int tempRating = 0;
	// check for pairs and multiply number by 1
	tempRating += (1 * hasPair (tempHand));
	// check for three of a kinds and multiply number by 2
	tempRating += (2 * hasThreeKind (tempHand));
	// check for four of a kinds and multiply number by 3
	tempRating += (3 * hasFourKind (tempHand));
	// check for flushes and multiply number by 4
	tempRating += (4 * hasFlush (tempHand));
	// check for straights and multiply number by 5
	tempRating += (5 * hasStraight (tempHand));
	// return the rating
	return tempRating;
}

/*************************************************************
 * Function: hasPair ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function checks for pairs in the player's hand
 * Input parameters: the player's hand
 * Returns: the number of pairs
 * Preconditions: the number of pairs needs to be found out
 * Postconditions: the number of pairs has been found out
 *************************************************************/
int hasPair (PlayerHand tempHand)
{
	// set pair count to 0
	int pairs = 0,
		 cardMain = 0, cardSub = 0, sameCount = 0;

	// determine pair count
	while (pairs == 0)
	{
		for (cardMain = 0; cardMain < 5; cardMain++)
		{
			for (cardSub = cardMain; cardSub < 5; cardSub++)
			{
				if (tempHand.hand[cardMain].face ==
					tempHand.hand[cardSub].face)
				{
					sameCount++;
					if (sameCount == 2)
					{
						pairs++;
					}
				}
			}
		}
		// if no pairs have been found, break the loop
		if (pairs == 0)
		{
			pairs = -1;
		}
	}
	
	// if there were no pairs, set pair count to 0
	if (pairs == -1)
	{
		pairs = 0;
	}

	// return pair count
	return pairs;
}

/*************************************************************
 * Function: hasThreeKind ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function checks for three of a kinds in the player's hand
 * Input parameters: the player's hand
 * Returns: the number of three of a kinds
 * Preconditions: the number of three of a kinds needs to be found out
 * Postconditions: the number of three of a kinds has been found out
 *************************************************************/
int hasThreeKind (PlayerHand tempHand)
{
	// set threeKind count to 0
	int threeKind = 0,
		 cardMain = 0, cardSub = 0, sameCount = 0;

	// determine threeKind count
	while (threeKind == 0)
	{
		for (cardMain = 0; cardMain < 5; cardMain++)
		{
			for (cardSub = cardMain; cardSub < 5; cardSub++)
			{
				if (tempHand.hand[cardMain].face ==
					tempHand.hand[cardSub].face)
				{
					sameCount++;
					if (sameCount == 3)
					{
						threeKind++;
					}
				}
			}
		}
		// if no threeKinds have been found, break the loop
		if (threeKind == 0)
		{
			threeKind = -1;
		}
	}
	
	// if there were no threeKinds, set threeKind count to 0
	if (threeKind == -1)
	{
		threeKind = 0;
	}

	// return threeKind count
	return threeKind;
}

/*************************************************************
 * Function: hasFourKind ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function checks for four of a kinds in the player's hand
 * Input parameters: the player's hand
 * Returns: the number of four of a kinds
 * Preconditions: the number of four of a kinds needs to be found out
 * Postconditions: the number of four of a kinds has been found out
 *************************************************************/
int hasFourKind (PlayerHand tempHand)
{
	// set fourKind count to 0
	int fourKind = 0,
		 cardMain = 0, cardSub = 0, sameCount = 0;

	// determine fourKind count
	while (fourKind == 0)
	{
		for (cardMain = 0; cardMain < 5; cardMain++)
		{
			for (cardSub = cardMain; cardSub < 5; cardSub++)
			{
				if (tempHand.hand[cardMain].face ==
					tempHand.hand[cardSub].face)
				{
					sameCount++;
					if (sameCount == 4)
					{
						fourKind++;
					}
				}
			}
		}
		// if no fourKinds have been found, break the loop
		if (fourKind == 0)
		{
			fourKind = -1;
		}
	}
	
	// if there were no fourKinds, set pair count to 0
	if (fourKind == -1)
	{
		fourKind = 0;
	}

	// return fourKind count
	return fourKind;
}

/*************************************************************
 * Function: hasFlush ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function checks for flurshes in the player's hand
 * Input parameters: the player's hand
 * Returns: the number of flushes
 * Preconditions: the number of flushes needs to be found out
 * Postconditions: the number of flushes has been found out
 *************************************************************/
int hasFlush (PlayerHand tempHand)
{
	// set flush count to 0
	int flush = 0;

	// determine if all the cards in the hand are from the same suit
	if (tempHand.hand[0].suit ==
		tempHand.hand[1].suit ==
		tempHand.hand[2].suit ==
		tempHand.hand[3].suit ==
		tempHand.hand[4].suit)
	{
		flush = 1;
	}

	// return flush count
	return flush;
}

/*************************************************************
 * Function: hasStraight ()
 * Date Created: November 13th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function checks for straights in the player's hand
 * Input parameters: the player's hand
 * Returns: the number of straights
 * Preconditions: the number of straights needs to be found out
 * Postconditions: the number of straights has been found out
 *************************************************************/
int hasStraight (PlayerHand tempHand)
{
	// set straight count to 0
	int straight = 0,
		 cardMain = 0, cardSub = 0, sameCount = 0;

	// order the hand
	orderCards (tempHand);

	// determine if there is a straight
	if ((tempHand.hand[4].face == (tempHand.hand[0].face + 4)) &&
		(tempHand.hand[3].face == (tempHand.hand[0].face + 3)) &&
		(tempHand.hand[2].face == (tempHand.hand[0].face + 2)) &&
		(tempHand.hand[1].face == (tempHand.hand[0].face + 1)))
	{
		straight = 1;
	}

	// return straight count
	return straight;
}