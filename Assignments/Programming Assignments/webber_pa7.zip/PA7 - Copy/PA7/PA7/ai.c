/**********************************************************************************************
 * Programmer: Christian Webber
 * Class: CptS 121, Fall 2011; Lab Section 3
 * PA7
 * Created: November 30th, 2011
 * Last Revised: November 30th, 2011
 *
 * File Description: "ai.c" contains the function definitions for the AI systems.
 *********************************************************************************************/
#include "poker.h"

/*************************************************************
 * Function: ai_main ()
 * Date Created: November 30th, 2011
 * Date Last Modified: November 30th, 2011
 * Description: This function controls the ai of a player and
 *					decides what it wants to do.
 * Input parameters: the player information of the ai player.
 * Returns: the updated player information of the ai player.
 * Preconditions: the ai player must decide what to do
 * Postconditions: the ai player has decided what to do
 *************************************************************/
PlayerInfo ai_main (PlayerInfo aiInfo, int bettingPhase)
{
	// set up variables
	int randomCard1 = 0,
		randomCard2 = 0,
		randomCard3 = 0,
		i = 0;
	double wagerPercent = 0.0;

	// get a rating of the ai player's hand
	aiInfo.handRating = handRating (aiInfo.hand);
	// if the rating is a 1...
	if (aiInfo.handRating == 1)
	{
		if (bettingPhase == 1)
		{
			// remove 3 cards
			randomCard1 = randomNumber (0, 5);
			do
			{
				randomCard2 = randomNumber (0, 5);
			} while (randomCard1 == randomCard2);
			do
			{
				randomCard3 = randomNumber (0, 5);
			} while ((randomCard1 == randomCard3) || (randomCard2 == randomCard3));
			aiInfo.hand.hand[randomCard1].face = -1;
			aiInfo.hand.hand[randomCard1].suit = -1;
			aiInfo.hand.hand[randomCard2].face = -1;
			aiInfo.hand.hand[randomCard2].suit = -1;
			aiInfo.hand.hand[randomCard3].face = -1;
			aiInfo.hand.hand[randomCard3].suit = -1;
		}
		// make wager
		wagerPercent = 0.025;
	}
	// if the rating is a 2...
	else if (aiInfo.handRating == 2)
	{
		if (bettingPhase == 1)
		{
			// remove 2 cards
			randomCard1 = randomNumber (0, 5);
			do
			{
				randomCard2 = randomNumber (0, 5);
			} while (randomCard1 == randomCard2);
			aiInfo.hand.hand[randomCard1].face = -1;
			aiInfo.hand.hand[randomCard1].suit = -1;
			aiInfo.hand.hand[randomCard2].face = -1;
			aiInfo.hand.hand[randomCard2].suit = -1;
		}
		// make wager
		wagerPercent = 0.05;
	}
	// if the rating is a 3...
	else if (aiInfo.handRating == 3)
	{
		if (bettingPhase == 1)
		{
			// remove 1 card
			randomCard1 = randomNumber (0, 5);
			aiInfo.hand.hand[randomCard1].face = -1;
			aiInfo.hand.hand[randomCard1].suit = -1;
		}
		// make wager
		wagerPercent = 0.1;
	}
	// if the rating is a 4...
	else if (aiInfo.handRating == 4)
	{
		if (bettingPhase == 1)
		{
			// remove 1 card
			randomCard1 = randomNumber (0, 5);
			aiInfo.hand.hand[randomCard1].face = -1;
			aiInfo.hand.hand[randomCard1].suit = -1;
		}
		// make wager
		wagerPercent = 0.25;
	}
	// if the rating is a 5...
	else if (aiInfo.handRating == 5)
	{
		// don't remove card
		// make wager
		i = randomNumber (0, 2);
		if (!i)
		{
			wagerPercent = 0.5;
		}
		else
		{
			wagerPercent = 1;
		}
	}
	// if the rating is a 0...
	else
	{
		if (bettingPhase == 1)
		{
			// remove 3 cards
			randomCard1 = randomNumber (0, 5);
			do
			{
				randomCard2 = randomNumber (0, 5);
			} while (randomCard1 == randomCard2);
			do
			{
				randomCard3 = randomNumber (0, 5);
			} while ((randomCard1 == randomCard3) || (randomCard2 == randomCard3));
			aiInfo.hand.hand[randomCard1].face = -1;
			aiInfo.hand.hand[randomCard1].suit = -1;
			aiInfo.hand.hand[randomCard2].face = -1;
			aiInfo.hand.hand[randomCard2].suit = -1;
			aiInfo.hand.hand[randomCard3].face = -1;
			aiInfo.hand.hand[randomCard3].suit = -1;
		}
		// make wager
		wagerPercent = 0.01;
	}

	// randomly (1%) go all in occassionally (regardless of what the hand is rated as)
	i = randomNumber (0, 100);
	// if i is a 0...
	if (!i)
	{
		// go all in
		wagerPercent = 1;
	}

	// increase/set the wager amount (based on current money and current wager as well as
	//         the wager percent setup for the hand)
	aiInfo.wager += wagerPercent * (aiInfo.money - aiInfo.wager);
	// return the updated ai player's info.
	return aiInfo;
}