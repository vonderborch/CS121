/**********************************************************************************************
 * Programmer: Christian Webber
 * Class: CptS 121, Fall 2011; Lab Section 3
 * PA7
 * Created: November 13th, 2011
 * Last Revised: November 30th, 2011
 *
 * File Description: "poker.h" contains the various includes, typedefs, and function
 *									prototypes which control the project uses.
 *********************************************************************************************/
#ifndef POKER_H
#define POKER_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "menu_system.h"
#include "common_functions.h"

// Typedefs
typedef struct card
{
	int suit;
	int face;
} Card;
typedef struct playerHand
{
	Card hand[5];
} PlayerHand;
typedef struct playerInfo
{
	int isAI;
	int hasFolded;
	int handRating;
	double money;
	double wager;
	PlayerHand hand;
} PlayerInfo;

// game_control.c
void game_main (void);

// functionc.c
void welcome (void);
void display_rules (void);
int randomNumber (int minNum, int maxNum);
int goodIntInputCheck (int minGood, int maxGood);
double goodDoubleInputCheck (double minGood, double maxGood);

// ai.c
PlayerInfo ai_main (PlayerInfo aiInfo, int bettingPhase);

// game_function.c
void shuffle (int wDeck[][13]);
double startingMoney (void);
Card dealCard (int wDeck[][13], int cardOn);
PlayerHand orderCards (PlayerHand tempHand);
double placeWager (double playerMoney);
void viewHand (PlayerHand tempHand, const char *wFace[], const char *wSuit[]);
PlayerHand removeCards (PlayerHand tempHand, const char *wFace[], const char *wSuit[]);
int handRating (PlayerHand tempHand);
int hasPair (PlayerHand tempHand);
int hasThreeKind (PlayerHand tempHand);
int hasFourKind (PlayerHand tempHand);
int hasFlush (PlayerHand tempHand);
int hasStraight (PlayerHand tempHand);

#endif